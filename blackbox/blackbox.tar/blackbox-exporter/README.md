# Prometheus Blackbox-exporter


Documentation: https://lapee79.github.io/en/article/monitoring-http-using-blackbox-exporter/
https://faun.pub/endpoint-monitoring-with-prometheus-and-blackbox-exporter-301ca7e49d6d

### Deployment

#Deployment steps

```
kubectl --namespace=monitoring apply -f configmap.yaml

```

```
kubectl --namespace=monitoring apply -f service.yaml

```

```
kubectl --namespace=monitoring apply -f deployment.yaml

```

Add scrape-config.txt in to prometheus configmap